import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PrincipalComponent } from './principal/principal.component';
import { VinculacionComponent } from './vinculacion/vinculacion.component';
import { LoginComponent } from './login/login.component';
import { APP_ROUTES } from './app.routes';
import { RouterModule} from '@angular/router';
import { ProfileComponent } from './pages/profile/profile.component';
import { FooterComponent } from './component/footer/footer.component';
import { NavbarComponent } from './component/navbar/navbar.component';



const routes =[
      {path: '', component: PrincipalComponent},
      {path: 'Login', component: LoginComponent},
      {path: 'vinculacion', component: VinculacionComponent},
      {path: 'principal', component: PrincipalComponent},
      {path: 'profile', component: ProfileComponent},
      {path: 'footer', component: FooterComponent},
      {path: 'navbar', component: NavbarComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    PrincipalComponent,
    VinculacionComponent,
    LoginComponent,
    ProfileComponent,
    FooterComponent,
    NavbarComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    APP_ROUTES,
    RouterModule.forRoot(routes),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
