import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vinculacion',
  templateUrl: './vinculacion.component.html',
  styleUrls: ['./vinculacion.component.css']
})
export class VinculacionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
