import { RouterModule } from '@angular/router';
import { PrincipalComponent } from './principal/principal.component';
import { LoginComponent } from './login/login.component';
import { VinculacionComponent } from './vinculacion/vinculacion.component';
import { Routes } from '@angular/router';
import { ProfileComponent } from './pages/profile/profile.component';
import { FooterComponent } from './component/footer/footer.component';
import { NavbarComponent } from './component/navbar/navbar.component';
//import { RouterModule, Routes } from '@angular/router';

const appRoutes: Routes = [
   {path: '', component: PrincipalComponent},
   {path: 'principal', component: PrincipalComponent},
   {path: 'login', component: LoginComponent},
   {path: 'vinculacion', component: VinculacionComponent},
   {path: 'profile', component: ProfileComponent},
   {path: 'footer', component: FooterComponent},
   {path: 'navbar', component: NavbarComponent},

   { path: '', redirectTo: '/profile', pathMatch: 'full'}
 
]
export const APP_ROUTES = RouterModule.forRoot (appRoutes, { useHash: true });
